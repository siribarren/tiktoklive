import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Input } from './ui/input';
import {
  Radio,
  MessageSquare,
  Sparkles,
  TrendingUp,
  ArrowRight,
  Play,
} from 'lucide-react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import { Link, useNavigate, useSearchParams } from 'react-router';
import { type FormEvent, useEffect, useMemo, useState } from 'react';
import { useRecorderBridge } from '../data/useRecorderBridge';
import { Tabs, TabsList, TabsTrigger } from './ui/tabs';
import { readJsonResponse, resolveApiErrorMessage } from '../../lib/http';

const normalizeUniqueId = (value?: string) => {
  const trimmed = (value ?? '').trim();
  if (!trimmed) {
    return '';
  }
  return trimmed.startsWith('@') ? trimmed.toLowerCase() : `@${trimmed.toLowerCase()}`;
};
const DELETED_ACCOUNTS_STORAGE_KEY = 'ember:deleted-accounts';

export function Dashboard() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const {
    allMessages,
    allLeads,
    liveSessions,
    runningTargets,
    liveStatuses,
  } = useRecorderBridge();
  const LIVE_STATUS_FRESHNESS_MS = 90 * 1000;
  const [newTarget, setNewTarget] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionMessage, setSubmissionMessage] = useState<string | null>(null);
  const [deletedAccounts, setDeletedAccounts] = useState<Set<string>>(() => {
    if (typeof window === 'undefined') {
      return new Set<string>();
    }

    try {
      const rawValue = window.localStorage.getItem(DELETED_ACCOUNTS_STORAGE_KEY);
      if (!rawValue) {
        return new Set<string>();
      }
      const parsedValue = JSON.parse(rawValue) as string[];
      return new Set(parsedValue.map((item) => normalizeUniqueId(item)).filter(Boolean));
    } catch {
      return new Set<string>();
    }
  });

  useEffect(() => {
    if (typeof window === 'undefined') {
      return;
    }

    const syncDeletedAccounts = () => {
      try {
        const rawValue = window.localStorage.getItem(DELETED_ACCOUNTS_STORAGE_KEY);
        if (!rawValue) {
          setDeletedAccounts(new Set<string>());
          return;
        }
        const parsedValue = JSON.parse(rawValue) as string[];
        setDeletedAccounts(new Set(parsedValue.map((item) => normalizeUniqueId(item)).filter(Boolean)));
      } catch {
        setDeletedAccounts(new Set<string>());
      }
    };

    syncDeletedAccounts();
    window.addEventListener('storage', syncDeletedAccounts);
    return () => {
      window.removeEventListener('storage', syncDeletedAccounts);
    };
  }, []);
  // Bloque aislado: métricas por cuenta monitoreada (fácil de revertir)
  const [selectedMonitoredAccountTab, setSelectedMonitoredAccountTab] = useState('');
  const requestedMonitoredAccount = normalizeUniqueId(searchParams.get('account') ?? undefined);
  const monitoredAccounts = useMemo(
    () =>
      Array.from(
        new Set(
          runningTargets
            .map((target) => normalizeUniqueId(target))
            .filter((target) => Boolean(target && !deletedAccounts.has(target)))
        )
      ),
    [runningTargets, deletedAccounts]
  );
  const runningTargetSet = useMemo(
    () => new Set(runningTargets.map((target) => normalizeUniqueId(target)).filter(Boolean)),
    [runningTargets]
  );
  const monitoredAccountState = useMemo(() => {
    const mapped = new Map<
      string,
      {
        isMonitoring: boolean;
        isOnline: boolean;
        hasRecentValidation: boolean;
        statusLabel: string;
      }
    >();

    for (const account of monitoredAccounts) {
      const isMonitoring = runningTargetSet.has(account);
      const status = liveStatuses[account];
      const checkedAtMs = status?.checkedAt?.getTime() ?? 0;
      const hasRecentValidation =
        checkedAtMs > 0 && Date.now() - checkedAtMs <= LIVE_STATUS_FRESHNESS_MS;
      const isOnline =
        isMonitoring &&
        hasRecentValidation &&
        status?.status === 'online';

      const statusLabel = isOnline
        ? 'En vivo'
        : isMonitoring
        ? hasRecentValidation
          ? 'Monitoreando'
          : 'Sin estado reciente'
        : 'Sin monitoreo';

      mapped.set(account, {
        isMonitoring,
        isOnline,
        hasRecentValidation,
        statusLabel,
      });
    }

    return mapped;
  }, [LIVE_STATUS_FRESHNESS_MS, liveStatuses, monitoredAccounts, runningTargetSet]);
  const visibleMonitoredAccounts = useMemo(
    () =>
      monitoredAccounts.filter((account) => {
        const accountState = monitoredAccountState.get(account);
        return accountState?.isOnline === true;
      }),
    [
      monitoredAccounts,
      monitoredAccountState,
    ]
  );
  const selectedMonitoredAccount = monitoredAccounts.includes(selectedMonitoredAccountTab)
    ? selectedMonitoredAccountTab
    : requestedMonitoredAccount && monitoredAccounts.includes(requestedMonitoredAccount)
    ? requestedMonitoredAccount
    : monitoredAccounts[0] || '';
  const resolvedSelectedMonitoredAccount = visibleMonitoredAccounts.includes(selectedMonitoredAccount)
    ? selectedMonitoredAccount
    : visibleMonitoredAccounts[0] || '';
  const connectedUsersByAccount = useMemo(() => {
    const mapped = new Map<string, number>();

    for (const account of visibleMonitoredAccounts) {
      const accountSessions = liveSessions.filter(
        (session) => normalizeUniqueId(session.accountName) === account
      );
      const latestSession = accountSessions.reduce<(typeof liveSessions)[number] | null>(
        (latest, current) => {
          if (!latest) {
            return current;
          }
          return current.startTime.getTime() > latest.startTime.getTime() ? current : latest;
        },
        null
      );
      const isOnline = monitoredAccountState.get(account)?.isOnline ?? false;
      mapped.set(account, isOnline ? latestSession?.viewers ?? 0 : 0);
    }

    return mapped;
  }, [visibleMonitoredAccounts, liveSessions, monitoredAccountState]);
  const sessionsByAccount = useMemo(() => {
    const mapped = new Map<string, (typeof liveSessions)>();
    for (const session of liveSessions) {
      const accountId = normalizeUniqueId(session.accountName);
      if (!accountId) {
        continue;
      }
      const current = mapped.get(accountId) ?? [];
      current.push(session);
      mapped.set(accountId, current);
    }
    return mapped;
  }, [liveSessions]);
  const selectedSessions = resolvedSelectedMonitoredAccount
    ? sessionsByAccount.get(resolvedSelectedMonitoredAccount) ?? []
    : [];
  const selectedSessionIds = useMemo(
    () =>
      new Set(
        selectedSessions
          .flatMap((session) => [String(session.rawSessionId ?? '').trim(), String(session.id ?? '').trim()])
          .filter(Boolean)
      ),
    [selectedSessions]
  );
  const selectedMessages = useMemo(() => {
    if (selectedSessionIds.size === 0 || !resolvedSelectedMonitoredAccount) {
      return [];
    }
    return allMessages.filter((message) => selectedSessionIds.has(String(message.sessionId ?? '').trim()));
  }, [allMessages, resolvedSelectedMonitoredAccount, selectedSessionIds]);
  const selectedLeads = useMemo(() => {
    if (!resolvedSelectedMonitoredAccount) {
      return [];
    }
    return allLeads.filter((lead) => {
      const leadAccount = normalizeUniqueId(lead.accountUniqueId);
      if (leadAccount === resolvedSelectedMonitoredAccount) {
        return true;
      }
      return lead.messages.some((message) => selectedSessionIds.has(String(message.sessionId ?? '').trim()));
    });
  }, [allLeads, resolvedSelectedMonitoredAccount, selectedSessionIds]);
  const selectedAccountLabel = resolvedSelectedMonitoredAccount;
  const isSelectedAccountLive = resolvedSelectedMonitoredAccount
    ? monitoredAccountState.get(resolvedSelectedMonitoredAccount)?.isOnline === true
    : false;
  const recentLeads = selectedLeads.slice(0, 5);
  const activeSessions = isSelectedAccountLive ? 1 : 0;
  const hasConnectedAccounts = Boolean(selectedMonitoredAccount);
  const sessionMessagesCount = hasConnectedAccounts ? selectedMessages.length : 0;
  const sessionLeadsCount = hasConnectedAccounts ? selectedLeads.length : 0;
  const qualifiedLeads = hasConnectedAccounts
    ? selectedLeads.filter((lead) => lead.totalScore >= 7).length
    : 0;

  const messagesByMinute = new Map<string, number>();
  if (hasConnectedAccounts) {
    for (const message of selectedMessages) {
      const bucket = message.timestamp.toLocaleTimeString('es-CL', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: false,
      });
      messagesByMinute.set(bucket, (messagesByMinute.get(bucket) ?? 0) + 1);
    }
  }
  const messagesData = hasConnectedAccounts
    ? Array.from(messagesByMinute.entries())
        .sort((a, b) => a[0].localeCompare(b[0]))
        .slice(-12)
        .map(([time, total], idx) => ({
          id: `msg-${idx}`,
          time,
          messages: total,
        }))
    : [{ id: 'msg-empty', time: '00:00', messages: 0 }];

  const categoryTotals = new Map<string, number>();
  if (hasConnectedAccounts) {
    for (const lead of selectedLeads) {
      for (const category of lead.categories) {
        categoryTotals.set(category, (categoryTotals.get(category) ?? 0) + 1);
      }
    }
  }
  const categoriesData = hasConnectedAccounts
    ? Array.from(categoryTotals.entries())
        .sort((a, b) => b[1] - a[1])
        .slice(0, 6)
        .map(([category, count], idx) => ({
          id: `cat-${idx}`,
          category,
          count,
        }))
    : [{ id: 'cat-empty', category: 'Sin datos', count: 0 }];

  const sessionAccountById = new Map<string, string>();
  for (const session of liveSessions) {
    const sessionIdCandidates = [String(session.id ?? '').trim(), String(session.rawSessionId ?? '').trim()];
    for (const sessionId of sessionIdCandidates) {
      if (!sessionId) {
        continue;
      }
      sessionAccountById.set(sessionId, session.accountName);
    }
  }

  const getLeadAccountName = (lead: (typeof recentLeads)[number]) => {
    if (lead.messages.length === 0) {
      return 'Sin cuenta';
    }

    const latestMessage = lead.messages.reduce((latest, current) =>
      current.timestamp.getTime() > latest.timestamp.getTime() ? current : latest
    );
    const messageSessionId = String(latestMessage.sessionId ?? '').trim();

    if (!messageSessionId) {
      return 'Sin cuenta';
    }

    return sessionAccountById.get(messageSessionId) ?? 'Sin cuenta';
  };

  const formatLeadActivity = (date: Date) => {
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const meridiem = date.getHours() >= 12 ? 'pm' : 'am';
    return `${day}/${month}/${year}-${hours}:${minutes}${meridiem}`;
  };

  const handleStartMonitoring = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const trimmed = newTarget.trim();
    if (!trimmed) {
      setSubmissionMessage('Ingresa un usuario de TikTok para comenzar a monitorearlo.');
      return;
    }

    setIsSubmitting(true);
    setSubmissionMessage(null);

    try {
      const response = await fetch('/recorder-api/targets', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ unique_id: trimmed }),
      });

      const payload = await readJsonResponse<{
        ok?: boolean;
        started?: boolean;
        unique_id?: string;
        error?: string;
      }>(response);

      if (!response.ok || !payload?.ok) {
        throw new Error(resolveApiErrorMessage(response, payload, 'No se pudo iniciar el monitoreo.'));
      }

      const account = payload.unique_id || trimmed;
      setSubmissionMessage(
        payload.started
          ? `Se inició el monitoreo para ${account}.`
          : `${account} ya estaba siendo monitoreado.`
      );
      setNewTarget('');
    } catch (error) {
      const message = error instanceof Error ? error.message : 'No se pudo conectar con el recorder local.';
      setSubmissionMessage(message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-gray-900">Panel</h1>
      </div>

      <Card className="border-amber-200 bg-gradient-to-r from-amber-50 to-white">
        <CardContent className="pt-6">
          <div className="space-y-4">
            <div>
              <h2 className="text-2xl font-semibold text-gray-900">Agrega la cuenta a monitorear</h2>
            </div>
            <form className="flex items-center gap-3" onSubmit={handleStartMonitoring}>
              <Input
                value={newTarget}
                onChange={(event) => setNewTarget(event.target.value)}
                placeholder="@usuario.tiktok"
                className="max-w-sm bg-white"
              />
              <Button className="gap-2 bg-amber-600 hover:bg-amber-700" disabled={isSubmitting}>
                <Play className="w-4 h-4" />
                {isSubmitting ? 'Iniciando...' : 'Monitorear'}
              </Button>
            </form>
            {submissionMessage ? (
              <p className="text-sm text-gray-700">{submissionMessage}</p>
            ) : null}
          </div>
        </CardContent>
      </Card>

      {/* Bloque aislado: tabs de cuentas monitoreadas (fácil de revertir) */}
      <Card className="border-slate-200">
        <CardContent className="pt-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="text-lg font-semibold text-gray-900">Métricas por cuenta monitoreada</h2>
              <p className="text-sm text-gray-500">
                Selecciona una cuenta monitoreada para ver sus métricas por separado.
              </p>
            </div>
            <Badge variant="outline" className="bg-emerald-50 text-emerald-700 border-emerald-200">
              {selectedAccountLabel ? `Cuenta monitoreada: ${selectedAccountLabel}` : 'Sin cuenta monitoreada'}
            </Badge>
          </div>
          {visibleMonitoredAccounts.length > 0 ? (
            <Tabs
              value={resolvedSelectedMonitoredAccount}
              onValueChange={setSelectedMonitoredAccountTab}
              className="mt-4"
            >
              <TabsList className="h-auto w-full flex-wrap justify-start bg-slate-100 p-1">
                {visibleMonitoredAccounts.map((account) => {
                  const accountState = monitoredAccountState.get(account);
                  const isOnline = accountState?.isOnline === true;
                  const statusLabel = accountState?.statusLabel ?? 'Sin estado';
                  return (
                  <TabsTrigger
                    key={account}
                    value={account}
                    className="h-auto flex-none border border-transparent px-3 py-2 text-xs transition-all data-[state=active]:border-blue-700 data-[state=active]:bg-blue-600 data-[state=active]:text-white data-[state=active]:shadow-lg data-[state=active]:ring-2 data-[state=active]:ring-blue-200 data-[state=active]:[&_.tab-underline]:bg-white data-[state=active]:[&_.tab-status]:text-blue-100 data-[state=active]:[&_.tab-users-badge]:border-white/30 data-[state=active]:[&_.tab-users-badge]:bg-white/15 data-[state=active]:[&_.tab-users-badge]:text-white data-[state=active]:[&_.active-chip]:inline-flex"
                  >
                    <div className="flex flex-col items-start gap-1">
                      <div className="flex items-center gap-1">
                        <span>{account}</span>
                        <Badge
                          variant="outline"
                          className="tab-users-badge h-5 px-1.5 text-[10px] border-blue-200 bg-blue-50 text-blue-700"
                        >
                          {connectedUsersByAccount.get(account)?.toLocaleString() ?? '0'}
                        </Badge>
                        <span className="active-chip hidden items-center rounded-full bg-white/20 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wide">
                          En vivo
                        </span>
                      </div>
                      <span
                        className={`tab-status text-[10px] ${
                          isOnline ? 'text-emerald-700' : 'text-slate-600'
                        }`}
                      >
                        {statusLabel}
                      </span>
                      <span className="tab-underline block h-0.5 w-full rounded-full bg-transparent transition-colors" />
                    </div>
                  </TabsTrigger>
                  );
                })}
              </TabsList>
            </Tabs>
          ) : (
            <p className="mt-4 text-sm text-gray-500">
              No hay cuentas con monitoreo activo y estado reciente. Agrega una cuenta para comenzar.
            </p>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-4 gap-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Sesiones activas</p>
                <p className="text-3xl font-semibold text-gray-900 mt-2">
                  {activeSessions}
                </p>
                <div className="flex items-center gap-1 mt-2">
                  <div
                    className={`w-2 h-2 rounded-full ${isSelectedAccountLive ? 'bg-green-500 animate-pulse' : 'bg-slate-400'}`}
                  />
                  <span className={`text-xs ${isSelectedAccountLive ? 'text-green-600' : 'text-slate-500'}`}>
                    {isSelectedAccountLive && selectedAccountLabel
                      ? `${selectedAccountLabel} en vivo`
                      : 'Sin sesión en vivo activa'}
                  </span>
                </div>
              </div>
              <div className="w-12 h-12 bg-green-50 rounded-lg flex items-center justify-center">
                <Radio className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Mensajes capturados</p>
                <p className="text-3xl font-semibold text-gray-900 mt-2">
                  {sessionMessagesCount.toLocaleString()}
                </p>
                <p className="text-xs text-gray-500 mt-2">En la sesión actual</p>
              </div>
              <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
                <MessageSquare className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Leads detectados</p>
                <p className="text-3xl font-semibold text-gray-900 mt-2">
                  {sessionLeadsCount}
                </p>
                <div className="flex items-center gap-1 mt-2 text-green-600">
                  <TrendingUp className="w-3 h-3" />
                  <span className="text-xs">Mensajes con puntaje acumulado positivo</span>
                </div>
              </div>
              <div className="w-12 h-12 bg-amber-50 rounded-lg flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-amber-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500">Leads calificados</p>
                <p className="text-3xl font-semibold text-gray-900 mt-2">
                  {qualifiedLeads}
                </p>
                <p className="text-xs text-gray-500 mt-2">Puntaje acumulado ≥ 7</p>
              </div>
              <div className="w-12 h-12 bg-violet-50 rounded-lg flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-violet-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Mensajes por minuto</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={messagesData}>
                <XAxis
                  dataKey="time"
                  stroke="#9ca3af"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis stroke="#9ca3af" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'white',
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="messages"
                  stroke="#3b82f6"
                  strokeWidth={2}
                  dot={false}
                  isAnimationActive={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Categorías por lead</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={categoriesData}>
                <XAxis
                  dataKey="category"
                  stroke="#9ca3af"
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis stroke="#9ca3af" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'white',
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                  }}
                />
                <Bar dataKey="count" fill="#3b82f6" radius={[8, 8, 0, 0]} isAnimationActive={false} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle>Leads recientes</CardTitle>
          <Link to="/leads">
            <Button variant="ghost" size="sm" className="gap-2">
              Ver todos
              <ArrowRight className="w-4 h-4" />
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          <div className="w-full">
            <table className="w-full table-fixed">
              <colgroup>
                <col className="w-[10%]" />
                <col className="w-[16%]" />
                <col className="w-[16%]" />
                <col className="w-[8%]" />
                <col className="w-[18%]" />
                <col className="w-[20%]" />
                <col className="w-[12%]" />
              </colgroup>
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-2 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Estado
                  </th>
                  <th className="text-left py-3 px-2 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Usuario
                  </th>
                  <th className="text-left py-3 px-2 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Cuenta monitoreada
                  </th>
                  <th className="text-left py-3 px-2 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Puntaje
                  </th>
                  <th className="text-left py-3 px-2 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Categorías
                  </th>
                  <th className="text-left py-3 px-2 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Último mensaje
                  </th>
                  <th className="text-left py-3 px-2 text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Última actividad
                  </th>
                </tr>
              </thead>
              <tbody>
                {recentLeads.map((lead) => {
                  const scoreColor =
                    lead.totalScore >= 7
                      ? 'bg-green-50 text-green-700 border-green-200'
                      : lead.totalScore >= 5
                      ? 'bg-amber-50 text-amber-700 border-amber-200'
                      : 'bg-gray-50 text-gray-700 border-gray-200';

                  return (
                    <tr
                      key={lead.id}
                      className="border-b border-gray-100 hover:bg-gray-50 cursor-pointer"
                      role="button"
                      tabIndex={0}
                      onClick={() => navigate(`/leads/${lead.id}`)}
                      onKeyDown={(event) => {
                        if (event.key === 'Enter' || event.key === ' ') {
                          event.preventDefault();
                          navigate(`/leads/${lead.id}`);
                        }
                      }}
                    >
                      <td className="py-3 px-2 align-top">
                        <Badge
                          variant="outline"
                          className={
                            lead.status === 'New'
                              ? 'bg-blue-50 text-blue-700 border-blue-200'
                              : lead.status === 'Qualified'
                              ? 'bg-green-50 text-green-700 border-green-200'
                              : lead.status === 'Contacted'
                              ? 'bg-violet-50 text-violet-700 border-violet-200'
                              : 'bg-gray-50 text-gray-700 border-gray-200'
                          }
                        >
                          {lead.status === 'New'
                            ? 'Nuevo'
                            : lead.status === 'Qualified'
                            ? 'Calificado'
                            : lead.status === 'Contacted'
                            ? 'Contactado'
                            : 'Revisado'}
                        </Badge>
                      </td>
                      <td className="py-3 px-2 align-top">
                        <div>
                          <p className="text-sm font-medium text-gray-900 break-all">
                            {lead.username}
                          </p>
                          <p className="text-xs text-gray-500 break-words">{lead.nickname}</p>
                        </div>
                      </td>
                      <td className="py-3 px-2 align-top">
                        <p className="text-sm text-gray-600 break-all">{getLeadAccountName(lead)}</p>
                      </td>
                      <td className="py-3 px-2 align-top">
                        <Badge variant="outline" className={scoreColor}>
                          {lead.totalScore}
                        </Badge>
                      </td>
                      <td className="py-3 px-2 align-top">
                        <div className="flex gap-1 flex-wrap">
                          {lead.categories.slice(0, 3).map((cat) => (
                            <Badge
                              key={cat}
                              variant="secondary"
                              className="text-xs bg-gray-100 text-gray-700"
                            >
                              {cat}
                            </Badge>
                          ))}
                        </div>
                      </td>
                      <td className="py-3 px-2 align-top">
                        <p className="text-sm text-gray-600 break-words">
                          {lead.lastMessage}
                        </p>
                      </td>
                      <td className="py-3 px-2 align-top">
                        <p className="text-sm text-gray-500">
                          {formatLeadActivity(new Date(lead.lastActivity))}
                        </p>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
